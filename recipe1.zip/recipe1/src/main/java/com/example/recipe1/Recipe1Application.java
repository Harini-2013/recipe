package com.example.recipe1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Recipe1Application {

	public static void main(String[] args) {
		SpringApplication.run(Recipe1Application.class, args);
	}

}
